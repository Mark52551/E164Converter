/* Created by: Mark Ruiz | Last Modified on November 13th, 2017 */
#pragma once
#include <iostream>
#include <string>

class phoneNumber
{
public:
	void welcome(); //welcome function
	void takeInputConvert(); //convert number function
	phoneNumber(); //const
	~phoneNumber(); //dest
};

